
public interface MaintainDocs {
 //public void add(Document doc);
 public void remove(String name);
 public void update(String name);
 
}
