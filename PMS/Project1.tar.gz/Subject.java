
public interface Subject {
public void register(Observer o);
public void notifyAllBuyers();
public void remove(Observer o);



}
