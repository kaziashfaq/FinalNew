
public class Promotion {
	int ID;
	
	public void sendPromotion() {
		
	}
}
