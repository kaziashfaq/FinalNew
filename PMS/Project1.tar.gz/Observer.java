import java.util.Vector;

public interface Observer {
	public void update(Vector<Document> docs);
}
